import torch
import torch.nn.functional as F
import random
import argparse
import time

from torch_sparse import SparseTensor

from dataset_mnist import dataset_mnist
from util import Logger, str2bool
from elasticgnn import get_model
from train_eval import train, test

import numpy as np



def Eu_dis(x):
    """
    Calculate the distance among each raw of x
    :param x: N X D
                N: the object number
                D: Dimension of the feature
    :return: N X N distance matrix
    """
    x = np.mat(x)
    aa = np.sum(np.multiply(x, x), 1)
    ab = x * x.T
    dist_mat = aa + aa.T - 2 * ab
    dist_mat[dist_mat < 0] = 0
    dist_mat = np.sqrt(dist_mat)
    dist_mat = np.maximum(dist_mat, dist_mat.T)
    return dist_mat



def graph_construct(X, k_neig=10):
    """
    param:
        X: N_object x feature_number
        k_neig: the number of neighbor expansion
    return:
        A: N_object x N_object
    """

    dis_mat = Eu_dis(X)
    n_obj = dis_mat.shape[0]
    A = np.zeros((n_obj, n_obj))
    for center_idx in range(n_obj):
        dis_mat[center_idx, center_idx] = 0
        dis_vec = dis_mat[center_idx]
        nearest_idx = np.array(np.argsort(dis_vec)).squeeze()
        if not np.any(nearest_idx[:k_neig] == center_idx):
            nearest_idx[k_neig - 1] = center_idx

        for node_idx in nearest_idx[:k_neig]:
            A[node_idx, center_idx] = 1.0
    return A




N_LABEL = 1000
MNIST_NUM_INPUT_FEATURES = 784
MNIST_NUM_CLASSES = 10
DATA_SET = 'mnist'

def parse_args():
    parser = argparse.ArgumentParser(description='ElasticGNN')
    parser.add_argument('--device', type=int, default=0)
    parser.add_argument('--log_steps', type=int, default=200)

    parser.add_argument('--model', type=str, default='ElasticGNN')
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--hidden_channels', type=int, default=64)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--weight_decay', type=float, default=0.0005)
    parser.add_argument('--lr', type=float, default=0.01)
    parser.add_argument('--epochs', type=int, default=500)
    parser.add_argument('--runs', type=int, default=10)
    parser.add_argument('--normalize_features', type=str2bool, default=True)
    parser.add_argument('--random_splits', type=int, default=0, help='default: fix split')
    parser.add_argument('--seed', type=int, default=12321312)
    parser.add_argument('--K', type=int, default=10)
    parser.add_argument('--lambda1', type=float, default=3)
    parser.add_argument('--lambda2', type=float, default=3)
    parser.add_argument('--L21', type=str2bool, default=True)
    parser.add_argument('--ptb_rate', type=float, default=0)
    # dataset
    parser.add_argument('--dataset', type=str, default=DATA_SET, metavar='featuresET', help="cifar10, mini or tiered")
    parser.add_argument('--n_label', type=int, default=N_LABEL, metavar='n_label', help="number of labeled data")
    parser.add_argument('--data_root', default='/mnt/Code/data/mnist/', type=str, metavar='FILE',
                        help='dir of image data')

    args = parser.parse_args()
    args.ogb = True if 'ogb' in args.dataset.lower() else False
    return args

def main():
    args = parse_args()
    print(args)

    if args.seed is not None:
        random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
    # device = torch.device(device)

    if args.random_splits > 0:
        random_split_num = args.random_splits
        print(f'random split {random_split_num} times and each for {args.runs} runs')
    else:
        random_split_num = 1
        print(f'fix split and run {args.runs} times')

    logger = Logger(args.runs * random_split_num)

    total_start = time.perf_counter()

    model = get_model(args)
    print(model)
    model.cuda(0)

    loader = dataset_mnist(args)
    features, labels, idx_train, idx_val, idx_test = loader.load_data()

    print("Graph construct...")
    adj = graph_construct(features)
    edge_num = np.count_nonzero(adj)
    adj = torch.from_numpy(adj).float()
    adj_index = torch.nonzero(adj).t()
    row = adj_index[0].cuda(0)
    col = adj_index[1].cuda(0)
    value = torch.ones(edge_num).float().cuda(0)

    print('edge_num:', edge_num)
    print('row:', row.shape)
    print('col:', col.shape)
    print('value:', value.shape)

    adj = SparseTensor(row=row, rowptr=None, col=col, value=value,
                       sparse_sizes=(edge_num, edge_num))
    adj = adj.cuda(0)


    features = torch.from_numpy(features).float()
    labels = torch.from_numpy(labels)
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    features = features.cuda(0)
    labels = labels.cuda(0)
    idx_train = idx_train.cuda(0)
    idx_val = idx_val.cuda(0)
    idx_test = idx_test.cuda(0)


    ## multiple run for each split
    for run in range(args.runs):
        model.reset_parameters()
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

        t_start = time.perf_counter()
        for epoch in range(1, 1 + args.epochs):
            args.current_epoch = epoch
            loss = train(model, features, labels,adj, idx_train, optimizer)
            print(loss)
            result = test(model, features, labels,adj, idx_val)


            if args.log_steps > 0:
                if epoch % args.log_steps == 0:
                    train_acc, valid_acc, test_acc = result
                    print(
                          f'Run: {run + 1:02d}, '
                          f'Epoch: {epoch:02d}, '
                          f'Loss: {loss:.4f}, '
                          f'Train: {100 * train_acc:.2f}%, '
                          f'Valid: {100 * valid_acc:.2f}% '
                          f'Test: {100 * test_acc:.2f}%')

        t_end = time.perf_counter()
        duration = t_end - t_start


    total_end = time.perf_counter()
    total_duration = total_end - total_start
    print('total time: ', total_duration)
    logger.print_statistics()

if __name__ == "__main__":
    main()

