import torch
import torch.nn.functional as F
# from ogb.nodeproppred import Evaluator

def train(model, features, labels,adj, idx_train, optimizer):
    model.train()
    optimizer.zero_grad()
    out = model(features, adj)[idx_train]

    y = labels[idx_train]

    loss = F.nll_loss(out, y)
    loss.backward()
    optimizer.step()
    return loss.item()

@torch.no_grad()
def test(model, features, labels, adj, idx_val):
    model.eval()
    out = model(features, adj)[idx_val]
    y_pred = out.argmax(dim=-1, keepdim=True)

    y = labels[idx_val]

    train_acc=None
    valid_acc=None
    test_acc=None
    
    return train_acc, valid_acc, test_acc