from .svhn import SVHN
from .cifar10 import Cifar10ZCA
